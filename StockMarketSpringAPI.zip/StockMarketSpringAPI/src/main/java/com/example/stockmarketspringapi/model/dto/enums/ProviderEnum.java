package com.example.stockmarketspringapi.model.dto.enums;

public enum ProviderEnum {
    GOOGLE, EMAIL
}
