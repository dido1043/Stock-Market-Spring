package com.example.stockmarketspringapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class
StockMarketSpringApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockMarketSpringApiApplication.class, args);
    }

}
